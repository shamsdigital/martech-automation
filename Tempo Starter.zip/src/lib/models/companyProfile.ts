export interface CompanyProfile {
  id: string;
  companyName: string;
  contactName: string;
  position: string;
  email: string;
  phone: string;
  website: string;
  isDefault?: boolean;
}

export const defaultCompanyProfile: CompanyProfile = {
  id: "default",
  companyName: "Digital Growth Agency",
  contactName: "John Smith",
  position: "SEO Specialist",
  email: "contact@digitalgrowthagency.com",
  phone: "(555) 123-4567",
  website: "www.digitalgrowthagency.com",
  isDefault: true,
};

// Function to get all company profiles from localStorage
export function getCompanyProfiles(): CompanyProfile[] {
  try {
    const savedProfiles = localStorage.getItem("companyProfiles");
    if (savedProfiles) {
      const profiles = JSON.parse(savedProfiles);
      // Ensure default profile exists
      if (!profiles.some((profile) => profile.id === "default")) {
        return [defaultCompanyProfile, ...profiles];
      }
      return profiles;
    }
    // If no profiles found in localStorage, return default profile
    return [defaultCompanyProfile];
  } catch (error) {
    console.error("Error loading company profiles:", error);
    return [defaultCompanyProfile];
  }
}

// Function to get the default company profile
export function getDefaultCompanyProfile(): CompanyProfile {
  const profiles = getCompanyProfiles();
  const defaultProfile = profiles.find((profile) => profile.isDefault);
  return defaultProfile || defaultCompanyProfile;
}

// Function to save a new company profile
export function saveCompanyProfile(
  profile: Omit<CompanyProfile, "id">,
): CompanyProfile {
  try {
    const profiles = getCompanyProfiles();
    const newProfile = {
      ...profile,
      id: `profile-${Date.now()}`,
    };

    // If this is marked as default, remove default from others
    const updatedProfiles = newProfile.isDefault
      ? profiles.map((p) => ({ ...p, isDefault: false }))
      : [...profiles];

    const finalProfiles = [...updatedProfiles, newProfile];
    localStorage.setItem("companyProfiles", JSON.stringify(finalProfiles));

    return newProfile;
  } catch (error) {
    console.error("Error saving company profile:", error);
    throw new Error("Failed to save company profile");
  }
}

// Function to update an existing company profile
export function updateCompanyProfile(
  id: string,
  profile: Omit<CompanyProfile, "id">,
): CompanyProfile {
  try {
    const profiles = getCompanyProfiles();
    const updatedProfile = { ...profile, id };

    // If this is marked as default, remove default from others
    let updatedProfiles = profiles.filter((p) => p.id !== id);
    if (updatedProfile.isDefault) {
      updatedProfiles = updatedProfiles.map((p) => ({
        ...p,
        isDefault: false,
      }));
    }

    const finalProfiles = [...updatedProfiles, updatedProfile];
    localStorage.setItem("companyProfiles", JSON.stringify(finalProfiles));

    return updatedProfile;
  } catch (error) {
    console.error("Error updating company profile:", error);
    throw new Error("Failed to update company profile");
  }
}

// Function to delete a company profile
export function deleteCompanyProfile(id: string): boolean {
  try {
    // Don't allow deleting the default profile
    if (id === "default") {
      return false;
    }

    const profiles = getCompanyProfiles();
    const profileToDelete = profiles.find((p) => p.id === id);
    const updatedProfiles = profiles.filter((profile) => profile.id !== id);

    // If we're deleting the default profile, set a new default
    if (profileToDelete?.isDefault && updatedProfiles.length > 0) {
      updatedProfiles[0].isDefault = true;
    }

    localStorage.setItem("companyProfiles", JSON.stringify(updatedProfiles));
    return true;
  } catch (error) {
    console.error("Error deleting company profile:", error);
    return false;
  }
}
