import { ExtractedData } from "./extraction";
import { getDefaultCompanyProfile } from "./companyProfile";

export interface EmailTemplate {
  id: string;
  name: string;
  subject: (data: ExtractedData) => string;
  body: (data: ExtractedData) => string;
}

export interface EmailData {
  recipient: string;
  subject: string;
  body: string;
  cc?: string;
  bcc?: string;
}

export interface EmailGenerationResult {
  success: boolean;
  data?: EmailData;
  error?: string;
}

// Collection of email templates
export const emailTemplates: EmailTemplate[] = [
  {
    id: "introduction",
    name: "Professional Introduction",
    subject: (data) =>
      `Introduction: Potential Collaboration with ${data.title}`,
    body: (data) => `Dear Team at ${data.title},

I recently came across your website and was impressed by ${data.summary}

I would love to connect and discuss how our services could help support your business goals. Our expertise could be valuable for your organization, particularly in relation to ${data.keyPoints[0]}.

Would you be available for a brief call next week to discuss potential collaboration opportunities?

Best regards,
John Smith
Digital Growth Agency
contact@digitalgrowthagency.com
(555) 123-4567`,
  },
  {
    id: "inquiry",
    name: "Service Inquiry",
    subject: (data) => `Enhancing ${data.title}'s Business Growth`,
    body: (data) => `Hello,

I'm reaching out regarding our services that I believe would benefit ${data.title}.

Based on my research of your website, I understand that your company focuses on ${data.summary}

Our comprehensive business solutions are specifically designed to help companies like yours improve performance and attract more qualified leads. I noticed that you mention ${data.keyPoints[1]}, which is an area where our solutions have helped similar organizations achieve significant improvements.

I'd love to schedule a brief call to discuss how we can help you achieve your business goals.

Best regards,
John Smith
Digital Growth Agency
contact@digitalgrowthagency.com
(555) 123-4567`,
  },
  {
    id: "followup",
    name: "Follow-up After Research",
    subject: (data) => `Custom business solution for ${data.title}`,
    body: (data) => `Dear ${data.title} Team,

I hope this email finds you well. I've been analyzing your company's online presence and believe our tailored services would be a perfect fit for your organization.

Your focus on ${data.summary} aligns perfectly with the solutions we provide.

Based on your website, I noticed these key areas where our expertise could add value:
- ${data.keyPoints[0]}
- ${data.keyPoints[1]}

We've helped similar companies in your industry achieve significant improvements through our specialized services.

I'd appreciate the opportunity to discuss a customized strategy for your specific needs. Would you have 15-20 minutes for a call in the coming week?

Best regards,
John Smith
Business Development
Digital Growth Agency
contact@digitalgrowthagency.com
(555) 123-4567`,
  },
  {
    id: "partnership",
    name: "Partnership Proposal",
    subject: (data) => `Partnership Opportunity with ${data.title}`,
    body: (data) => `Dear ${data.title} Team,

I hope this message finds you well. I'm reaching out because I see great potential for a strategic partnership between our organizations.

After reviewing your website, I'm impressed by ${data.summary} and believe there could be excellent synergy between our companies.

Specifically, I noticed these areas of potential collaboration:
- ${data.keyPoints[0]}
- ${data.keyPoints[1]}

A partnership could allow us to leverage our complementary strengths and provide enhanced value to our respective clients.

Would you be open to a conversation about how we might work together? I'd be happy to schedule a call at your convenience.

Best regards,
John Smith
Business Development
Digital Growth Agency
contact@digitalgrowthagency.com
(555) 123-4567`,
  },
  {
    id: "networking",
    name: "Professional Networking",
    subject: (data) => `Connecting with ${data.title}`,
    body: (data) => `Hello ${data.title} Team,

I hope you're doing well. I recently discovered your company and was particularly interested in ${data.summary}.

I'm reaching out to expand my professional network and connect with innovative companies like yours. Your work in ${data.keyPoints[0]} particularly caught my attention.

I'd love to learn more about your company's journey and share insights from my experience in the industry. Perhaps we could schedule a brief virtual coffee chat in the coming weeks?

Looking forward to potentially connecting.

Best regards,
John Smith
Digital Growth Agency
contact@digitalgrowthagency.com
(555) 123-4567`,
  },
];

import openai from "../openai";

// Function to generate email content based on extracted data and template
export function generateEmail(
  data: ExtractedData,
  templateId: string = "introduction",
): EmailGenerationResult {
  try {
    const companyProfile = getDefaultCompanyProfile();
    const template = emailTemplates.find((t) => t.id === templateId);

    if (!template) {
      return {
        success: false,
        error: "Email template not found",
      };
    }

    // Replace placeholders with company profile data
    let body = template.body(data);
    body = body.replace(
      /John Smith/g,
      companyProfile.contactName || "John Smith",
    );
    body = body.replace(
      /SEO Specialist/g,
      companyProfile.position || "SEO Specialist",
    );
    body = body.replace(
      /Digital Growth Agency/g,
      companyProfile.companyName || "Digital Growth Agency",
    );
    body = body.replace(
      /contact@digitalgrowthagency\.com/g,
      companyProfile.email || "contact@digitalgrowthagency.com",
    );
    body = body.replace(
      /\(555\) 123-4567/g,
      companyProfile.phone || "(555) 123-4567",
    );

    return {
      success: true,
      data: {
        recipient: data.contactEmail || `contact@${new URL(data.url).hostname}`,
        subject: template.subject(data),
        body: body,
      },
    };
  } catch (error) {
    return {
      success: false,
      error: "Failed to generate email content",
    };
  }
}

// Function to generate AI-powered email content with structured format
export async function generateAIEmail(
  data: ExtractedData,
  tone: string = "professional",
  purpose: string = "introduction",
): Promise<EmailGenerationResult> {
  // If purpose is longer than 20 characters, assume it's a custom prompt
  const isCustomPrompt = purpose.length > 20;
  const companyProfile = getDefaultCompanyProfile();

  // Create signature from company profile
  const signature = `${companyProfile.contactName || "John Smith"}${companyProfile.position ? "\n" + companyProfile.position : ""}\n${companyProfile.companyName}\n${companyProfile.email}\n${companyProfile.phone || ""}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are an email writing assistant for ${companyProfile.companyName}. Create a ${tone} business outreach email based on the provided website data. 

The email should be highly personalized to the specific company based on their website data and follow a structured format with:

1. A proper greeting
2. An introduction paragraph
3. 2-3 body paragraphs with bullet points for key benefits
4. A clear call to action
5. A professional closing

Create a compelling, specific subject line that mentions their company name. The email body should reference specific details from their website and explain how your services would benefit them specifically. Always sign emails with the provided signature information. Never use placeholder text.`,
        },
        {
          role: "user",
          content: isCustomPrompt
            ? `${purpose}\n\nUse this website data:\n\nWebsite: ${data.title}\nSummary: ${data.summary}\nKey Points: ${data.keyPoints.join(", ")}\n\nThe email should have a personalized subject line specific to this company and a detailed body that references their specific business needs. Format the response as JSON with the structure: {"subject": "...", "body": "..."} and ensure the body has proper paragraph breaks and formatting.\n\nUse this signature: ${signature}`
            : `Write a ${purpose} email using this website data:\n\nWebsite: ${data.title}\nSummary: ${data.summary}\nKey Points: ${data.keyPoints.join(", ")}\n\nThe email should have a personalized subject line specific to this company and a detailed body that offers our business services from ${companyProfile.companyName} to this company based on their specific needs. Reference specific details from their website data. Format the response as JSON with the structure: {"subject": "...", "body": "..."} and ensure the body has proper paragraph breaks, bullet points for benefits, and clear formatting.\n\nUse this signature: ${signature}`,
        },
      ],
      temperature: 0.7,
      max_tokens: 1000,
      response_format: { type: "json_object" },
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No content returned from OpenAI");
    }

    // Parse the JSON response
    const emailContent = JSON.parse(content);

    return {
      success: true,
      data: {
        recipient: data.contactEmail || `contact@${new URL(data.url).hostname}`,
        subject: emailContent.subject,
        body: emailContent.body,
      },
    };
  } catch (error) {
    console.error("AI email generation error:", error);

    // Fallback to template-based email if AI generation fails
    return generateEmail(
      data,
      purpose === "introduction"
        ? "introduction"
        : purpose === "inquiry"
          ? "inquiry"
          : "followup",
    );
  }
}
