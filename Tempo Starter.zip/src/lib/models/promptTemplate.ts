export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  prompt: string;
}

export const defaultPromptTemplates: PromptTemplate[] = [
  {
    id: "seo-offer",
    name: "SEO Service Proposal",
    description:
      "Introduce your SEO services and offer solutions to the lead's needs",
    prompt:
      "Write a service proposal email introducing our SEO services from Digital Growth Agency and how it can specifically help this company based on the information extracted from their website. Mention specific challenges they might be facing with online visibility and how our SEO solution addresses them. Reference specific information from their website to show we've done our research. Sign the email as John Smith, SEO Specialist at Digital Growth Agency with contact@digitalgrowthagency.com and (555) 123-4567.",
  },
  {
    id: "content-marketing",
    name: "Content Marketing Offer",
    description: "Offer content marketing services to improve their SEO",
    prompt:
      "Write an email offering our content marketing services from Digital Growth Agency to improve this company's SEO and online presence. Mention insights from their website that indicate potential content gaps, and how our expertise can help overcome these challenges with a comprehensive content strategy. Offer a free content audit. Sign the email as John Smith, Content Strategist at Digital Growth Agency with contact@digitalgrowthagency.com and (555) 123-4567.",
  },
  {
    id: "seo-case-studies",
    name: "SEO Case Study Showcase",
    description: "Share relevant SEO case studies with similar clients",
    prompt:
      "Write an email showcasing Digital Growth Agency's relevant SEO case studies with clients in the same industry as this company. Highlight specific results we've achieved (e.g., '65% increase in organic traffic', '40% improvement in conversion rates') and explain how we could apply the same SEO approach to their business based on the information from their website. Sign the email as John Smith, SEO Specialist at Digital Growth Agency with contact@digitalgrowthagency.com and (555) 123-4567.",
  },
];

// Function to get all prompt templates from localStorage
export function getPromptTemplates(): PromptTemplate[] {
  try {
    const savedTemplates = localStorage.getItem("promptTemplates");
    if (savedTemplates) {
      return JSON.parse(savedTemplates);
    }
    // If no templates found in localStorage, return default templates
    return defaultPromptTemplates;
  } catch (error) {
    console.error("Error loading prompt templates:", error);
    return defaultPromptTemplates;
  }
}

// Function to save a new prompt template
export function savePromptTemplate(
  template: Omit<PromptTemplate, "id">,
): PromptTemplate {
  try {
    const templates = getPromptTemplates();
    const newTemplate = {
      ...template,
      id: `template-${Date.now()}`,
    };

    const updatedTemplates = [...templates, newTemplate];
    localStorage.setItem("promptTemplates", JSON.stringify(updatedTemplates));

    return newTemplate;
  } catch (error) {
    console.error("Error saving prompt template:", error);
    throw new Error("Failed to save prompt template");
  }
}

// Function to delete a prompt template
export function deletePromptTemplate(id: string): boolean {
  try {
    const templates = getPromptTemplates();
    const updatedTemplates = templates.filter((template) => template.id !== id);

    localStorage.setItem("promptTemplates", JSON.stringify(updatedTemplates));
    return true;
  } catch (error) {
    console.error("Error deleting prompt template:", error);
    return false;
  }
}
