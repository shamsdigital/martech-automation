import OpenAI from "openai";

// Initialize the OpenAI client
const apiKey = import.meta.env.VITE_OPENAI_API_KEY || "";

const openai = new OpenAI({
  apiKey: apiKey,
  dangerouslyAllowBrowser: true, // For client-side usage
});

export default openai;
