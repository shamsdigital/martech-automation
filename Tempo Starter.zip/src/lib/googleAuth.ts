import { useEffect } from "react";

// Google API client ID
export const GOOGLE_CLIENT_ID =
  "3737921577-c2jucuj031fmjg66ci56s7i6u3hu0oob.apps.googleusercontent.com";

// Initialize the Google API client
export const initGoogleApi = (callback?: () => void) => {
  const loadGapiAndInitClient = () => {
    const script = document.createElement("script");
    script.src = "https://apis.google.com/js/api.js";
    script.onload = () => {
      window.gapi.load("client:auth2", () => {
        window.gapi.client
          .init({
            apiKey: "",
            clientId: GOOGLE_CLIENT_ID,
            discoveryDocs: [
              "https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest",
            ],
            scope: "https://www.googleapis.com/auth/gmail.send",
            ux_mode: "popup",
            redirect_uri: window.location.origin + window.location.pathname,
          })
          .then(() => {
            if (callback) callback();
          })
          .catch((error: any) => {
            console.error("Error initializing Google API client", error);
          });
      });
    };
    document.body.appendChild(script);
  };

  loadGapiAndInitClient();
};

// Hook to initialize Google API
export const useGoogleApi = (callback?: () => void) => {
  useEffect(() => {
    initGoogleApi(callback);
  }, [callback]);
};

// Check if user is signed in
export const isSignedIn = (): boolean => {
  if (!window.gapi || !window.gapi.auth2) return false;
  return window.gapi.auth2.getAuthInstance().isSignedIn.get();
};

// Sign in the user
export const signIn = async (): Promise<any> => {
  if (!window.gapi || !window.gapi.auth2) {
    throw new Error("Google API not initialized");
  }
  try {
    const authResponse = await window.gapi.auth2.getAuthInstance().signIn();
    return authResponse;
  } catch (error) {
    console.error("Error signing in with Google", error);
    throw error;
  }
};

// Sign out the user
export const signOut = async (): Promise<void> => {
  if (!window.gapi || !window.gapi.auth2) return;
  try {
    await window.gapi.auth2.getAuthInstance().signOut();
  } catch (error) {
    console.error("Error signing out from Google", error);
  }
};

// Send an email using Gmail API
export const sendEmail = async (
  to: string,
  subject: string,
  body: string,
): Promise<any> => {
  if (!isSignedIn()) {
    throw new Error("User not signed in");
  }

  try {
    // Create the email content
    const emailContent = [
      'Content-Type: text/plain; charset="UTF-8"\r\n',
      "MIME-Version: 1.0\r\n",
      "Content-Transfer-Encoding: 7bit\r\n",
      `to: ${to}\r\n`,
      `subject: ${subject}\r\n\r\n`,
      body,
    ].join("");

    // Encode the email to base64url format
    const encodedEmail = btoa(emailContent)
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    // Send the email
    const response = await window.gapi.client.gmail.users.messages.send({
      userId: "me",
      resource: {
        raw: encodedEmail,
      },
    });

    return response;
  } catch (error) {
    console.error("Error sending email", error);
    throw error;
  }
};

// Add type definitions for global window object
declare global {
  interface Window {
    gapi: any;
  }
}
