import { Suspense } from "react";
import { useRoutes, Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/home";
import LandingPage from "./components/LandingPage";
import React from "react";
import routes from "tempo-routes";

function App() {
  return (
    <Suspense
      fallback={
        <p>
          Loading...
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl">
            Header 1
          </h1>
        </p>
      }
    >
      <>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/extraction" element={<Home />} />
          <Route path="/email" element={<Home />} />
          <Route path="/history" element={<Home />} />
          <Route path="/admin" element={<Home />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        {import.meta.env.VITE_TEMPO === "true" && useRoutes(routes)}
      </>
    </Suspense>
  );
}

export default App;
