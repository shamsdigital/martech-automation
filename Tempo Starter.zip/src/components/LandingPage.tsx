import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./ui/button";
import {
  ArrowRight,
  FileText,
  Mail,
  History,
  Settings,
  MessageSquareText,
} from "lucide-react";

const LandingPage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/extraction");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="py-6 border-b bg-background shadow-sm">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            Martech Automation
          </h1>
          <Button
            onClick={handleGetStarted}
            className="flex items-center gap-2"
            variant="secondary"
          >
            Get Started <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </header>
      <main className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-5xl font-bold tracking-tight mb-6 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            From Website to Inbox: AI‑Driven Lead Gen & Email Automation
          </h2>
          <p className="text-xl text-muted-foreground mb-10 max-w-3xl mx-auto">
            Extract specific lead's data from online and generate personalized
            emails for effective marketing campaigns in minutes, not hours.
          </p>
          <div className="flex justify-center mb-20">
            <Button
              size="lg"
              onClick={handleGetStarted}
              className="flex items-center gap-2 px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Get Started <ArrowRight className="h-5 w-5 ml-1" />
            </Button>
          </div>

          <div className="mt-16 max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
              <FeatureCard
                title="Lead Extraction"
                description="Extract valuable contact information and company details from any website with a single click."
                icon={<FileText className="h-10 w-10 text-primary" />}
              />
              <FeatureCard
                title="Email Generation"
                description="Create personalized, context-aware emails based on extracted data using advanced AI technology."
                icon={<Mail className="h-10 w-10 text-primary" />}
              />
              <FeatureCard
                title="Efficient Data Crawl"
                description="Quickly gather and process large amounts of data from multiple sources with our optimized crawling technology."
                icon={<FileText className="h-10 w-10 text-primary" />}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard
                title="Prompt Templates"
                description="Create and manage reusable AI prompt templates to maintain consistent messaging across your team."
                icon={<MessageSquareText className="h-10 w-10 text-primary" />}
              />
              <FeatureCard
                title="Admin Settings"
                description="Customize application settings, manage user permissions, and configure integration preferences."
                icon={<Settings className="h-10 w-10 text-primary" />}
              />
              <FeatureCard
                title="Lead History"
                description="Keep track of all your leads, communications, and conversion metrics in one centralized dashboard."
                icon={<History className="h-10 w-10 text-primary" />}
              />
            </div>
          </div>
        </div>
      </main>
      <footer className="py-8 border-t bg-muted/40">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Martech Automation. All rights
            reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const FeatureCard = ({ title, description, icon }: FeatureCardProps) => {
  return (
    <div className="bg-card p-8 rounded-lg shadow-md border hover:shadow-lg transition-all duration-300 h-full">
      <div className="flex flex-col items-center text-center">
        <div className="mb-5 bg-primary/10 p-4 rounded-full">{icon}</div>
        <h3 className="text-xl font-semibold mb-3">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </div>
    </div>
  );
};

export default LandingPage;
