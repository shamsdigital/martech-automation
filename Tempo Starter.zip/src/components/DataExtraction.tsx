import React, { useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Clipboard, Loader2, AlertCircle, Mail } from "lucide-react";
import { useToast } from "./ui/use-toast";
import { extractDataFromUrl, ExtractedData } from "@/lib/models/extraction";
import { Alert, AlertDescription } from "./ui/alert";

interface DataExtractionProps {
  onDataExtracted?: (data: ExtractedData) => void;
  onProceedToEmail?: (data: ExtractedData) => void;
}

const DataExtraction = ({
  onDataExtracted = () => {},
  onProceedToEmail = () => {},
}: DataExtractionProps) => {
  const [url, setUrl] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value);
    setError(null);
  };

  const handleExtract = async () => {
    if (!url) {
      setError("Please enter a URL to extract data from");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await extractDataFromUrl(url);

      if (result.success && result.data) {
        setExtractedData(result.data);
        onDataExtracted(result.data);

        toast({
          title: "Success",
          description: "Data extracted successfully",
        });
      } else {
        setError(
          result.error || "Failed to extract data from the provided URL",
        );
        toast({
          title: "Error",
          description:
            result.error || "Failed to extract data from the provided URL",
          variant: "destructive",
        });
      }
    } catch (error) {
      setError("An unexpected error occurred. Please try again.");
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!extractedData) return;

    const textToCopy = `
      Title: ${extractedData.title}

      Summary: ${extractedData.summary}

      Contact: ${extractedData.contactEmail || "N/A"}

      Key Points:
      ${extractedData.keyPoints.map((point) => `- ${point}`).join("\n")}
      
      Detailed Summary:
      ${extractedData.detailedSummary || "Not available"}
      
      Discovered Subpages:
      ${extractedData.subpages ? extractedData.subpages.map((page) => `- ${page}`).join("\n") : "None discovered"}
    `;

    navigator.clipboard.writeText(textToCopy.trim());

    toast({
      title: "Copied",
      description: "Data copied to clipboard",
    });
  };

  const handleProceedToEmail = () => {
    if (extractedData) {
      onProceedToEmail(extractedData);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-background">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">
          Comprehensive Website Data Extraction
        </h2>
        <p className="text-muted-foreground">
          Enter a company website URL to extract detailed information of that
          business to send personalized AI generated email for business outreach
          based on your needs.
        </p>
      </div>

      <div className="flex gap-4 mb-4">
        <Input
          placeholder="Enter company website URL (e.g., https://jbhunt.com) to analyze all pages"
          value={url}
          onChange={handleUrlChange}
          className="flex-1"
        />
        <Button onClick={handleExtract} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Extracting...
            </>
          ) : (
            "Extract Comprehensive Data"
          )}
        </Button>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {extractedData && (
        <Card className="w-full">
          <CardHeader>
            <CardTitle>{extractedData.title}</CardTitle>
            <CardDescription>
              Extracted information from {extractedData.url}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium mb-1">Summary</h3>
              <p className="text-sm text-muted-foreground">
                {extractedData.summary}
              </p>
            </div>

            <div>
              <h3 className="font-medium mb-1">Contact Email</h3>
              <p className="text-sm text-muted-foreground">
                {extractedData.contactEmail || "No contact email found"}
              </p>
            </div>

            <div>
              <h3 className="font-medium mb-1">Key Points</h3>
              <ul className="list-disc pl-5 text-sm text-muted-foreground">
                {extractedData.keyPoints.map((point, index) => (
                  <li key={index}>{point}</li>
                ))}
              </ul>
            </div>

            {extractedData.detailedSummary && (
              <div>
                <h3 className="font-medium mb-1">
                  Detailed Summary (All Pages)
                </h3>
                <div className="max-h-60 overflow-y-auto rounded-md border p-4">
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {extractedData.detailedSummary}
                  </p>
                </div>
              </div>
            )}

            {extractedData.subpages && extractedData.subpages.length > 0 && (
              <div>
                <h3 className="font-medium mb-1">Discovered Subpages</h3>
                <ul className="list-disc pl-5 text-sm text-muted-foreground">
                  {extractedData.subpages.map((page, index) => (
                    <li key={index}>
                      <a
                        href={page}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        {page.replace(/^https?:\/\//, "").replace(/\/$/, "")}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handleCopy}>
              <Clipboard className="mr-2 h-4 w-4" />
              Copy to Clipboard
            </Button>
            <Button onClick={handleProceedToEmail}>
              <Mail className="mr-2 h-4 w-4" />
              Proceed to Generate Personal Email
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
};

export default DataExtraction;
