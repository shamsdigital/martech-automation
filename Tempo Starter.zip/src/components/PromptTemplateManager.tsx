import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { useToast } from "./ui/use-toast";
import { Plus, Trash2, Edit, Save, Pencil } from "lucide-react";
import {
  PromptTemplate,
  getPromptTemplates,
  savePromptTemplate,
  deletePromptTemplate,
} from "@/lib/models/promptTemplate";

interface PromptTemplateManagerProps {
  onSelectTemplate?: (template: PromptTemplate) => void;
}

const PromptTemplateManager = ({
  onSelectTemplate = () => {},
}: PromptTemplateManagerProps) => {
  const { toast } = useToast();
  const [templates, setTemplates] = useState<PromptTemplate[]>([]);
  const [newTemplate, setNewTemplate] = useState<{
    name: string;
    description: string;
    prompt: string;
  }>({
    name: "",
    description: "",
    prompt: "",
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editTemplateId, setEditTemplateId] = useState("");

  // Load templates on component mount
  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = () => {
    const loadedTemplates = getPromptTemplates();
    setTemplates(loadedTemplates);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setNewTemplate((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleEditTemplate = (template: PromptTemplate) => {
    setNewTemplate({
      name: template.name,
      description: template.description,
      prompt: template.prompt,
    });
    setEditTemplateId(template.id);
    setIsEditMode(true);
    setIsAddDialogOpen(true);
  };

  const handleSaveTemplate = () => {
    if (!newTemplate.name || !newTemplate.prompt) {
      toast({
        title: "Error",
        description: "Name and prompt are required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      if (isEditMode) {
        // Update existing template
        deletePromptTemplate(editTemplateId);
        savePromptTemplate(newTemplate);
        setIsEditMode(false);
        setEditTemplateId("");
      } else {
        // Save new template
        savePromptTemplate(newTemplate);
      }
      loadTemplates();
      setNewTemplate({
        name: "",
        description: "",
        prompt: "",
      });
      setIsAddDialogOpen(false);
      toast({
        title: "Success",
        description: isEditMode
          ? "Prompt template updated successfully"
          : "Prompt template saved successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save prompt template",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTemplate = (id: string) => {
    try {
      deletePromptTemplate(id);
      loadTemplates();
      toast({
        title: "Success",
        description: "Prompt template deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete prompt template",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="w-full bg-background">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Service Proposal Templates</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-1">
              <Plus className="h-4 w-4" />
              Add Template
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {isEditMode ? "Edit" : "Create New"} Service Proposal Template
              </DialogTitle>
              <DialogDescription>
                Save a template for your service proposals to use later
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Template Name</Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="e.g., SaaS Service Offer"
                  value={newTemplate.name}
                  onChange={handleInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Input
                  id="description"
                  name="description"
                  placeholder="Brief description of when to use this template"
                  value={newTemplate.description}
                  onChange={handleInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prompt">
                  Service Proposal Prompt (Instructions for AI)
                </Label>
                <Textarea
                  id="prompt"
                  name="prompt"
                  placeholder="Write a service proposal to introduce our services and offer a solution to the lead's needs..."
                  value={newTemplate.prompt}
                  onChange={handleInputChange}
                  className="min-h-[120px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveTemplate}>
                <Save className="h-4 w-4 mr-2" />
                {isEditMode ? "Update" : "Save"} Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {templates.length === 0 ? (
        <Card className="w-full text-center py-8">
          <CardContent>
            <p className="text-muted-foreground">
              No service proposal templates yet. Create one to get started.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {templates.map((template) => (
            <Card key={template.id} className="w-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{template.name}</CardTitle>
                {template.description && (
                  <CardDescription>{template.description}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="pb-2">
                <p className="text-sm text-muted-foreground line-clamp-3">
                  {template.prompt}
                </p>
              </CardContent>
              <CardFooter className="flex justify-between pt-2">
                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteTemplate(template.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditTemplate(template)}
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                </div>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => onSelectTemplate(template)}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Use Template
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default PromptTemplateManager;
