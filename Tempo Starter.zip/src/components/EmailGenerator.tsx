import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { useToast } from "./ui/use-toast";
import {
  Send,
  Copy,
  RefreshCw,
  Sparkles,
  BookTemplate,
  Mail,
  LogIn,
  LogOut,
} from "lucide-react";
import { ExtractedData } from "@/lib/models/extraction";
import {
  emailTemplates,
  generateEmail,
  generateAIEmail,
  EmailData,
} from "@/lib/models/email";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Switch } from "./ui/switch";
import PromptTemplateManager from "./PromptTemplateManager";
import { PromptTemplate } from "@/lib/models/promptTemplate";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  useGoogleApi,
  isSignedIn,
  signIn,
  signOut,
  sendEmail as sendGmailEmail,
} from "@/lib/googleAuth";

interface EmailGeneratorProps {
  extractedData?:
    | {
        email?: string;
        summary?: string;
      }
    | ExtractedData;
}

const EmailGenerator = ({
  extractedData = { email: "", summary: "" },
}: EmailGeneratorProps) => {
  const { toast } = useToast();
  const [emailData, setEmailData] = useState<EmailData>({
    recipient:
      (extractedData as any).contactEmail ||
      (extractedData as any).email ||
      "contact@example.com",
    subject: (extractedData as any).summary
      ? `Regarding ${(extractedData as any).summary.slice(0, 30)}...`
      : "Follow-up on our conversation",
    body: (extractedData as any).summary
      ? `Dear recipient,\n\nI recently came across your profile and noticed ${(extractedData as any).summary}\n\nI would love to connect and discuss potential opportunities for collaboration.\n\nBest regards,\nYour Name`
      : "Dear recipient,\n\nI hope this email finds you well. I would like to discuss a potential opportunity for collaboration.\n\nBest regards,\nYour Name",
  });

  const [selectedTemplate, setSelectedTemplate] = useState("introduction");
  const [isSending, setIsSending] = useState(false);
  const [useAI, setUseAI] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTone, setSelectedTone] = useState("professional");
  const [customPrompt, setCustomPrompt] = useState("");
  const [activeTab, setActiveTab] = useState("compose");
  const [googleAuthenticated, setGoogleAuthenticated] = useState(false);

  // Initialize Google API
  useGoogleApi(() => {
    setGoogleAuthenticated(isSignedIn());
  });

  // Check authentication status when component mounts
  useEffect(() => {
    const checkAuthStatus = () => {
      setGoogleAuthenticated(isSignedIn());
    };

    // Check initially
    checkAuthStatus();

    // Set up interval to check periodically
    const interval = setInterval(checkAuthStatus, 5000);

    return () => clearInterval(interval);
  }, []);

  // Generate email when template changes or when extracted data changes
  useEffect(() => {
    if ("title" in extractedData && "url" in extractedData) {
      if (!useAI) {
        const result = generateEmail(
          extractedData as ExtractedData,
          selectedTemplate,
        );
        if (result.success && result.data) {
          setEmailData(result.data);
        }
      } else {
        handleAIGeneration();
      }
    }
  }, [extractedData, useAI, selectedTemplate]); // Added selectedTemplate dependency back to ensure regeneration

  const handlePromptTemplateSelect = (template: PromptTemplate) => {
    setCustomPrompt(template.prompt);
    setActiveTab("compose");
    toast({
      title: "Template Selected",
      description: `Using "${template.name}" template for email generation`,
    });
  };

  const handleAIGeneration = async () => {
    if (!("title" in extractedData && "url" in extractedData)) return;

    setIsGenerating(true);
    try {
      // If we have a custom prompt from a template, use it instead of the standard template
      const purpose = customPrompt ? customPrompt : selectedTemplate;

      const result = await generateAIEmail(
        extractedData as ExtractedData,
        selectedTone,
        purpose,
      );

      if (result.success && result.data) {
        setEmailData(result.data);
        toast({
          title: "AI Email Generated",
          description: "Your personalized email has been created with AI",
        });
      } else {
        toast({
          title: "Generation Failed",
          description: result.error || "Failed to generate AI email",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate AI email. Using template instead.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setEmailData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleTemplateChange = (value: string) => {
    setSelectedTemplate(value);

    // Force immediate regeneration when template changes
    if ("title" in extractedData && "url" in extractedData) {
      const result = generateEmail(
        extractedData as ExtractedData,
        value, // Use the new value directly instead of waiting for state update
      );
      if (result.success && result.data) {
        setEmailData(result.data);
        toast({
          title: "Email Template Applied",
          description:
            "Email content has been updated with the selected template",
        });
      }
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      await signIn();
      setGoogleAuthenticated(true);
      toast({
        title: "Google Sign-In Successful",
        description: "You can now send emails through your Gmail account.",
        variant: "default",
      });
    } catch (error) {
      console.error("Google sign-in error:", error);
      toast({
        title: "Sign-In Failed",
        description: "Could not sign in to Google. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleGoogleSignOut = async () => {
    try {
      await signOut();
      setGoogleAuthenticated(false);
      toast({
        title: "Signed Out",
        description: "You have been signed out of your Google account.",
        variant: "default",
      });
    } catch (error) {
      console.error("Google sign-out error:", error);
    }
  };

  const handleSendEmail = async () => {
    setIsSending(true);

    try {
      if (googleAuthenticated) {
        // Send email using Gmail API
        await sendGmailEmail(
          emailData.recipient,
          emailData.subject,
          emailData.body,
        );

        toast({
          title: "Email Sent via Gmail",
          description:
            "Your email has been sent successfully through your Gmail account!",
          variant: "default",
        });
      } else {
        // Simulate sending email if not using Gmail
        await new Promise((resolve) => setTimeout(resolve, 1500));

        toast({
          title: "Email Sent (Simulation)",
          description:
            "This is a simulation. Sign in with Google to send real emails.",
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error sending email:", error);
      toast({
        title: "Email Sending Failed",
        description:
          error instanceof Error
            ? error.message
            : "Could not send email. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleCopyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: `${type} Copied`,
      description: `The ${type.toLowerCase()} has been copied to clipboard.`,
      variant: "default",
    });
  };

  const regenerateEmail = async () => {
    if ("title" in extractedData && "url" in extractedData) {
      if (!useAI) {
        const result = generateEmail(
          extractedData as ExtractedData,
          selectedTemplate,
        );
        if (result.success && result.data) {
          setEmailData(result.data);
          toast({
            title: "Email Regenerated",
            description:
              "Email content has been refreshed with the selected template",
          });
        }
      } else {
        await handleAIGeneration();
      }
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-background">
      <Card className="w-full shadow-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">
            Business Outreach Email Generator
          </CardTitle>
          <CardDescription>
            Customize and send personalized business outreach emails based on
            extracted website data{" "}
            {googleAuthenticated && (
              <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                Gmail Connected
              </span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="compose" className="flex items-center gap-2">
                <Send className="h-4 w-4" />
                Compose Email
              </TabsTrigger>
              <TabsTrigger
                value="templates"
                className="flex items-center gap-2"
              >
                <BookTemplate className="h-4 w-4" />
                Purpose Templates
              </TabsTrigger>
            </TabsList>
            <TabsContent value="compose" className="mt-4 space-y-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="ai-mode"
                    checked={useAI}
                    onCheckedChange={setUseAI}
                  />
                  <Label htmlFor="ai-mode" className="flex items-center gap-1">
                    <Sparkles className="h-4 w-4 text-yellow-500" />
                    AI-Powered Email
                  </Label>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={regenerateEmail}
                  disabled={isGenerating}
                  className="h-8 px-2"
                >
                  {isGenerating ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent mr-1"></div>
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-1" />
                  )}
                  Regenerate
                </Button>
              </div>

              {"title" in extractedData && (
                <div className="space-y-2">
                  {useAI ? (
                    <div className="space-y-2">
                      <Label htmlFor="tone">Email Tone</Label>
                      <Select
                        value={selectedTone}
                        onValueChange={setSelectedTone}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a tone" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="professional">
                            Professional
                          </SelectItem>
                          <SelectItem value="friendly">Friendly</SelectItem>
                          <SelectItem value="formal">Formal</SelectItem>
                          <SelectItem value="casual">Casual</SelectItem>
                          <SelectItem value="persuasive">Persuasive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="template">Email Template</Label>
                      <Select
                        value={selectedTemplate}
                        onValueChange={handleTemplateChange}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a template" />
                        </SelectTrigger>
                        <SelectContent>
                          {emailTemplates.map((template) => (
                            <SelectItem key={template.id} value={template.id}>
                              {template.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="recipient">Recipient</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      handleCopyToClipboard(emailData.recipient, "Recipient")
                    }
                    className="h-8 px-2"
                  >
                    <Copy className="h-4 w-4 mr-1" />
                    Copy
                  </Button>
                </div>
                <Input
                  id="recipient"
                  name="recipient"
                  value={emailData.recipient}
                  onChange={handleInputChange}
                  placeholder="recipient@example.com"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="subject">Subject Line</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      handleCopyToClipboard(emailData.subject, "Subject")
                    }
                    className="h-8 px-2"
                  >
                    <Copy className="h-4 w-4 mr-1" />
                    Copy
                  </Button>
                </div>
                <Input
                  id="subject"
                  name="subject"
                  value={emailData.subject}
                  onChange={handleInputChange}
                  placeholder="Enter email subject"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="body">Email Body</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      handleCopyToClipboard(emailData.body, "Email body")
                    }
                    className="h-8 px-2"
                  >
                    <Copy className="h-4 w-4 mr-1" />
                    Copy
                  </Button>
                </div>
                <Textarea
                  id="body"
                  name="body"
                  value={emailData.body}
                  onChange={handleInputChange}
                  placeholder="Enter your email content here"
                  className="min-h-[200px]"
                />
              </div>
            </TabsContent>
            <TabsContent value="templates" className="mt-4">
              <PromptTemplateManager
                onSelectTemplate={handlePromptTemplateSelect}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          {activeTab === "compose" && (
            <>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    handleCopyToClipboard(
                      `To: ${emailData.recipient}\nSubject: ${emailData.subject}\n\n${emailData.body}`,
                      "Full Email",
                    );
                  }}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy All
                </Button>

                {!googleAuthenticated ? (
                  <Button variant="outline" onClick={handleGoogleSignIn}>
                    <LogIn className="h-4 w-4 mr-2" />
                    Sign in with Google
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    onClick={handleGoogleSignOut}
                    size="sm"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </Button>
                )}
              </div>

              <Button
                onClick={handleSendEmail}
                disabled={isSending}
                className={
                  googleAuthenticated ? "bg-blue-600 hover:bg-blue-700" : ""
                }
              >
                {isSending ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    {googleAuthenticated ? (
                      <Mail className="h-4 w-4 mr-2" />
                    ) : (
                      <Send className="h-4 w-4 mr-2" />
                    )}
                    {googleAuthenticated
                      ? "Send via Gmail"
                      : "Send Email (Simulation)"}
                  </>
                )}
              </Button>
            </>
          )}
          {activeTab === "templates" && (
            <Button onClick={() => setActiveTab("compose")} className="ml-auto">
              Return to Compose
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default EmailGenerator;
