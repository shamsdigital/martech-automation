import React, { useState, useEffect } from "react";
import TabNavigation from "./TabNavigation";
import DataExtraction from "./DataExtraction";
import EmailGenerator from "./EmailGenerator";
import SearchHistory from "./SearchHistory";
import AdminSettings from "./AdminSettings";
import { Toaster } from "./ui/toaster";
import { ExtractedData } from "@/lib/models/extraction";

const Home = () => {
  const [activeTab, setActiveTab] = useState("extraction");
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(
    null,
  );
  const [searchHistory, setSearchHistory] = useState<ExtractedData[]>([]);

  // Load search history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("searchHistory");
    if (savedHistory) {
      try {
        setSearchHistory(JSON.parse(savedHistory));
      } catch (error) {
        console.error("Failed to parse search history:", error);
      }
    }
  }, []);

  // Save search history to localStorage whenever it changes
  useEffect(() => {
    if (searchHistory.length > 0) {
      localStorage.setItem("searchHistory", JSON.stringify(searchHistory));
    }
  }, [searchHistory]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleDataExtracted = (data: ExtractedData) => {
    setExtractedData(data);

    // Add to search history (avoid duplicates by URL)
    setSearchHistory((prev) => {
      const exists = prev.some((item) => item.url === data.url);
      if (!exists) {
        return [data, ...prev].slice(0, 10); // Keep only the 10 most recent searches
      }
      return prev;
    });
  };

  const handleProceedToEmail = (data: ExtractedData) => {
    setExtractedData(data);
    setActiveTab("email");
  };

  const handleSelectHistoryItem = (data: ExtractedData) => {
    setExtractedData(data);
    setActiveTab("extraction");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="py-4 border-b bg-background">
        <div className="container mx-auto px-4 flex flex-col items-center">
          <h1 className="text-2xl font-bold text-center">Martech Automation</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Extract website data and generate personalized emails for marketing
            outreach
          </p>
        </div>
      </header>

      <TabNavigation activeTab={activeTab} onTabChange={handleTabChange} />

      <main className="flex-1 container mx-auto px-4 py-6">
        {activeTab === "extraction" ? (
          <DataExtraction
            onDataExtracted={handleDataExtracted}
            onProceedToEmail={handleProceedToEmail}
          />
        ) : activeTab === "email" ? (
          <EmailGenerator
            extractedData={extractedData || { email: "", summary: "" }}
          />
        ) : activeTab === "history" ? (
          <SearchHistory
            searchHistory={searchHistory}
            onSelectHistoryItem={handleSelectHistoryItem}
            onGenerateEmail={handleProceedToEmail}
          />
        ) : (
          <AdminSettings />
        )}
      </main>

      <footer className="py-4 border-t bg-muted/40">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Martech Automation
        </div>
      </footer>

      <Toaster />
    </div>
  );
};

export default Home;
