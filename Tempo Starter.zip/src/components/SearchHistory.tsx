import React from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "./ui/card";
import { Button } from "./ui/button";
import { Clock, ExternalLink, Mail } from "lucide-react";
import { ExtractedData } from "@/lib/models/extraction";

interface SearchHistoryProps {
  searchHistory: ExtractedData[];
  onSelectHistoryItem: (data: ExtractedData) => void;
  onGenerateEmail: (data: ExtractedData) => void;
}

const SearchHistory = ({
  searchHistory = [],
  onSelectHistoryItem = () => {},
  onGenerateEmail = () => {},
}: SearchHistoryProps) => {
  if (searchHistory.length === 0) {
    return (
      <div className="w-full max-w-4xl mx-auto p-6 bg-background">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Lead History</h2>
          <p className="text-muted-foreground">
            Your previously extracted lead data will appear here
          </p>
        </div>

        <Card className="w-full text-center py-12">
          <CardContent>
            <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No search history yet</h3>
            <p className="text-muted-foreground mb-6">
              Extract data from your leads' websites to build your history
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-background">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Lead History</h2>
        <p className="text-muted-foreground">
          Your previously extracted lead data
        </p>
      </div>

      <div className="space-y-4">
        {searchHistory.map((item, index) => (
          <Card key={index} className="w-full">
            <CardHeader>
              <CardTitle className="flex justify-between items-start">
                <span>{item.title}</span>
                <span className="text-sm font-normal text-muted-foreground">
                  {new Date().toLocaleDateString()}
                </span>
              </CardTitle>
              <CardDescription>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 hover:underline"
                >
                  {item.url}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <h3 className="font-medium mb-1">Summary</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {item.summary}
                </p>
              </div>

              {item.contactEmail && (
                <div className="mb-4">
                  <h3 className="font-medium mb-1">Contact</h3>
                  <p className="text-sm text-muted-foreground">
                    {item.contactEmail}
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                variant="outline"
                onClick={() => onSelectHistoryItem(item)}
              >
                View Details
              </Button>
              <Button onClick={() => onGenerateEmail(item)}>
                <Mail className="h-4 w-4 mr-2" />
                Generate Email
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SearchHistory;
