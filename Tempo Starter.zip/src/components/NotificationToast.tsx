import React from "react";
import { CheckCircle, AlertCircle, Info, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

type NotificationType = "success" | "error" | "info";

interface NotificationToastProps {
  type?: NotificationType;
  title?: string;
  message?: string;
  duration?: number;
  onClose?: () => void;
}

const NotificationToast = ({
  type = "info",
  title = "Notification",
  message = "This is a notification message",
  duration = 5000,
  onClose,
}: NotificationToastProps) => {
  const { toast } = useToast();

  const showToast = React.useCallback(() => {
    const icons = {
      success: <CheckCircle className="h-5 w-5 text-green-500" />,
      error: <AlertCircle className="h-5 w-5 text-red-500" />,
      info: <Info className="h-5 w-5 text-blue-500" />,
    };

    const bgColors = {
      success: "bg-green-50 border-green-200",
      error: "bg-red-50 border-red-200",
      info: "bg-blue-50 border-blue-200",
    };

    toast({
      duration: duration,
      className: cn(
        "flex items-center gap-3 p-4 rounded-md border",
        bgColors[type],
      ),
      title: (
        <div className="flex items-center gap-2">
          {icons[type]}
          <span className="font-medium">{title}</span>
        </div>
      ),
      description: message,
      action: onClose ? (
        <button
          onClick={onClose}
          className="rounded-full p-1 hover:bg-gray-200 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      ) : undefined,
    });
  }, [toast, type, title, message, duration, onClose]);

  // Component for demonstration purposes
  return (
    <div className="bg-white p-4 rounded-md shadow-sm border border-gray-200">
      <h3 className="text-lg font-medium mb-4">Notification Preview</h3>
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          {type === "success" && (
            <CheckCircle className="h-5 w-5 text-green-500" />
          )}
          {type === "error" && <AlertCircle className="h-5 w-5 text-red-500" />}
          {type === "info" && <Info className="h-5 w-5 text-blue-500" />}
          <span className="font-medium">{title}</span>
        </div>
        <p className="text-gray-600">{message}</p>
        <button
          onClick={showToast}
          className="mt-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors w-fit"
        >
          Show Toast Notification
        </button>
      </div>
    </div>
  );
};

export default NotificationToast;
