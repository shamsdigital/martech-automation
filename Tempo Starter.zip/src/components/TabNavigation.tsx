import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "../components/ui/tabs";
import {
  FileText,
  Mail,
  History,
  Settings,
  Home as HomeIcon,
} from "lucide-react";
import { Button } from "./ui/button";

interface TabNavigationProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

const TabNavigation = ({
  activeTab = "extraction",
  onTabChange = () => {},
}: TabNavigationProps) => {
  const [currentTab, setCurrentTab] = useState(activeTab);
  const navigate = useNavigate();

  const handleTabChange = (value: string) => {
    setCurrentTab(value);
    onTabChange(value);
  };

  const handleHomeClick = () => {
    navigate("/");
  };

  return (
    <div className="w-full bg-background border-b shadow-sm">
      <div className="container mx-auto py-1 flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={handleHomeClick}
          className="flex items-center gap-2 mr-4"
        >
          <HomeIcon className="h-4 w-4" />
          <span className="font-medium">Home</span>
        </Button>

        <Tabs
          defaultValue={currentTab}
          onValueChange={handleTabChange}
          className="w-full"
        >
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-4 bg-muted/20 p-1 rounded-lg">
            <TabsTrigger
              value="extraction"
              className="flex items-center gap-2 py-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
            >
              <FileText className="h-4 w-4" />
              <span className="font-medium">Lead Extraction</span>
            </TabsTrigger>
            <TabsTrigger
              value="email"
              className="flex items-center gap-2 py-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
            >
              <Mail className="h-4 w-4" />
              <span className="font-medium">Email Generator</span>
            </TabsTrigger>
            <TabsTrigger
              value="history"
              className="flex items-center gap-2 py-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
            >
              <History className="h-4 w-4" />
              <span className="font-medium">Lead History</span>
            </TabsTrigger>
            <TabsTrigger
              value="admin"
              className="flex items-center gap-2 py-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
            >
              <Settings className="h-4 w-4" />
              <span className="font-medium">Admin</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
    </div>
  );
};

export default TabNavigation;
