import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useToast } from "./ui/use-toast";
import { Plus, Trash2, Pencil, Check, Star } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Switch } from "./ui/switch";
import {
  CompanyProfile,
  getCompanyProfiles,
  saveCompanyProfile,
  updateCompanyProfile,
  deleteCompanyProfile,
} from "@/lib/models/companyProfile";

const AdminSettings = () => {
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<CompanyProfile[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editProfileId, setEditProfileId] = useState("");
  const [formData, setFormData] = useState<Omit<CompanyProfile, "id">>({
    companyName: "",
    contactName: "",
    position: "",
    email: "",
    phone: "",
    website: "",
    isDefault: false,
  });

  // Load profiles on component mount
  useEffect(() => {
    loadProfiles();
  }, []);

  const loadProfiles = () => {
    const loadedProfiles = getCompanyProfiles();
    setProfiles(loadedProfiles);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleEditProfile = (profile: CompanyProfile) => {
    setFormData({
      companyName: profile.companyName,
      contactName: profile.contactName,
      position: profile.position,
      email: profile.email,
      phone: profile.phone,
      website: profile.website,
      isDefault: profile.isDefault || false,
    });
    setEditProfileId(profile.id);
    setIsEditMode(true);
    setIsDialogOpen(true);
  };

  const handleSaveProfile = () => {
    if (!formData.companyName || !formData.email) {
      toast({
        title: "Error",
        description: "Company name and email are required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      if (isEditMode) {
        // Update existing profile
        updateCompanyProfile(editProfileId, formData);
      } else {
        // Save new profile
        saveCompanyProfile(formData);
      }
      loadProfiles();
      resetForm();
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: isEditMode
          ? "Company profile updated successfully"
          : "Company profile saved successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save company profile",
        variant: "destructive",
      });
    }
  };

  const handleDeleteProfile = (id: string) => {
    try {
      const result = deleteCompanyProfile(id);
      if (result) {
        loadProfiles();
        toast({
          title: "Success",
          description: "Company profile deleted successfully",
        });
      } else {
        toast({
          title: "Error",
          description: "Cannot delete the default company profile",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete company profile",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      companyName: "",
      contactName: "",
      position: "",
      email: "",
      phone: "",
      website: "",
      isDefault: false,
    });
    setIsEditMode(false);
    setEditProfileId("");
  };

  const handleSetDefault = (id: string) => {
    try {
      const profile = profiles.find((p) => p.id === id);
      if (profile) {
        updateCompanyProfile(id, { ...profile, isDefault: true });
        loadProfiles();
        toast({
          title: "Success",
          description: `${profile.companyName} set as default company profile`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to set default company profile",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-background">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">Company Profiles</h2>
        <Dialog
          open={isDialogOpen}
          onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="flex items-center gap-1">
              <Plus className="h-4 w-4" />
              Add Company Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {isEditMode ? "Edit" : "Add New"} Company Profile
              </DialogTitle>
              <DialogDescription>
                {isEditMode
                  ? "Update your company information"
                  : "Add your company information for email signatures"}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="companyName" className="text-right">
                  Company Name
                </Label>
                <Input
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="contactName" className="text-right">
                  Contact Name
                </Label>
                <Input
                  id="contactName"
                  name="contactName"
                  value={formData.contactName}
                  onChange={handleInputChange}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="position" className="text-right">
                  Position
                </Label>
                <Input
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleInputChange}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                  Phone
                </Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="website" className="text-right">
                  Website
                </Label>
                <Input
                  id="website"
                  name="website"
                  value={formData.website}
                  onChange={handleInputChange}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="isDefault" className="text-right">
                  Set as Default
                </Label>
                <div className="col-span-3 flex items-center">
                  <Switch
                    id="isDefault"
                    name="isDefault"
                    checked={formData.isDefault}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, isDefault: checked }))
                    }
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveProfile}>
                {isEditMode ? "Update" : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {profiles.length === 0 ? (
        <Card className="w-full text-center py-8">
          <CardContent>
            <p className="text-muted-foreground">
              No company profiles yet. Add one to get started.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {profiles.map((profile) => (
            <Card
              key={profile.id}
              className={`w-full ${profile.isDefault ? "border-primary" : ""}`}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">
                      {profile.companyName}
                    </CardTitle>
                    {profile.isDefault && (
                      <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <Star className="h-3 w-3" />
                        <span>Default</span>
                      </div>
                    )}
                  </div>
                </div>
                {profile.website && (
                  <CardDescription>
                    <a
                      href={`https://${profile.website.replace(/^https?:\/\//, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline"
                    >
                      {profile.website}
                    </a>
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent className="pb-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="font-medium">Contact:</span>{" "}
                    {profile.contactName || "N/A"}
                    {profile.position && <span> ({profile.position})</span>}
                  </div>
                  <div>
                    <span className="font-medium">Email:</span> {profile.email}
                  </div>
                  {profile.phone && (
                    <div>
                      <span className="font-medium">Phone:</span>{" "}
                      {profile.phone}
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-2">
                <div className="flex gap-2">
                  {!profile.isDefault && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSetDefault(profile.id)}
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Set as Default
                    </Button>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditProfile(profile)}
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  {!profile.isDefault && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteProfile(profile.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminSettings;
